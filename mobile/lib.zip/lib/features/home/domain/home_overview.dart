class HomeOverview {
  final double income;
  final double expense;
  final double balance;
  final double savingsRate;

  const HomeOverview({
    required this.income,
    required this.expense,
    required this.balance,
    required this.savingsRate,
  });

  factory HomeOverview.fromJson(
    Map<String, dynamic> json,
  ) {
    return HomeOverview(
      income: _toDouble(json['income']),
      expense: _toDouble(json['expense']),
      balance: _toDouble(json['balance']),
      savingsRate: _toDouble(json['savings_rate']),
    );
  }

  static double _toDouble(dynamic value) {
    if (value is num) {
      return value.toDouble();
    }

    return double.tryParse(
          value?.toString() ?? '',
        ) ??
        0;
  }
}