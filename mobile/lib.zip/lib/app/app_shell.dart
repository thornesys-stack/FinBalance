import 'package:flutter/material.dart';

import '../features/account/data/account_repository.dart';
import '../features/home/presentation/home_page.dart';
import '../features/transaction/data/transaction_repository.dart';
import '../features/transaction/presentation/transaction_page.dart';

class AppShell extends StatefulWidget {
  const AppShell({
    super.key,
    required this.accountRepository,
    required this.transactionRepository,
  });

  final AccountRepository accountRepository;
  final TransactionRepository transactionRepository;

  @override
  State<AppShell> createState() => _AppShellState();
}

class _AppShellState extends State<AppShell> {
  int _currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    final pages = [
      HomePage(
        accountRepository:
            widget.accountRepository,
      ),

      TransactionPage(
        transactionRepository:
            widget.transactionRepository,
      ),

      const _PlaceholderPage(
        title: 'AI 财务助手',
        subtitle: 'AI 财务分析与智能建议',
        icon: Icons.auto_awesome_rounded,
      ),

      const _PlaceholderPage(
        title: '财务分析',
        subtitle: '了解你的消费与资金变化',
        icon: Icons.analytics_rounded,
      ),

      const _PlaceholderPage(
        title: '账户管理',
        subtitle: '管理你的账户与数据连接',
        icon: Icons.account_balance_wallet_rounded,
      ),
    ];

    return Scaffold(
      body: IndexedStack(
        index: _currentIndex,
        children: pages,
      ),

      bottomNavigationBar:
          NavigationBar(
        selectedIndex: _currentIndex,

        onDestinationSelected: (index) {
          setState(() {
            _currentIndex = index;
          });
        },

        destinations: const [
          NavigationDestination(
            icon: Icon(
              Icons.home_outlined,
            ),
            selectedIcon: Icon(
              Icons.home_rounded,
            ),
            label: '首页',
          ),

          NavigationDestination(
            icon: Icon(
              Icons.receipt_long_outlined,
            ),
            selectedIcon: Icon(
              Icons.receipt_long_rounded,
            ),
            label: '交易',
          ),

          NavigationDestination(
            icon: Icon(
              Icons.auto_awesome_outlined,
            ),
            selectedIcon: Icon(
              Icons.auto_awesome_rounded,
            ),
            label: 'AI',
          ),

          NavigationDestination(
            icon: Icon(
              Icons.analytics_outlined,
            ),
            selectedIcon: Icon(
              Icons.analytics_rounded,
            ),
            label: '分析',
          ),

          NavigationDestination(
            icon: Icon(
              Icons.account_circle_outlined,
            ),
            selectedIcon: Icon(
              Icons.account_circle_rounded,
            ),
            label: '账户',
          ),
        ],
      ),
    );
  }
}

class _PlaceholderPage extends StatelessWidget {
  const _PlaceholderPage({
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final String title;
  final String subtitle;
  final IconData icon;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.all(32),
            child: Column(
              mainAxisAlignment:
                  MainAxisAlignment.center,
              children: [
                Container(
                  width: 76,
                  height: 76,
                  decoration: BoxDecoration(
                    color: theme
                        .colorScheme
                        .primaryContainer,
                    borderRadius:
                        BorderRadius.circular(24),
                  ),
                  child: Icon(
                    icon,
                    size: 36,
                    color:
                        theme.colorScheme.primary,
                  ),
                ),

                const SizedBox(height: 22),

                Text(
                  title,
                  style: theme
                      .textTheme
                      .titleLarge,
                ),

                const SizedBox(height: 8),

                Text(
                  subtitle,
                  textAlign: TextAlign.center,
                  style: theme
                      .textTheme
                      .bodyMedium,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}